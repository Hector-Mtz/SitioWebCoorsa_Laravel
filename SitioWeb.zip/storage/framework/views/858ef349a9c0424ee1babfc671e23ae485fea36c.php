<?php if (isset($component)) { $__componentOriginal039602449bf45efe51ab811d0812b22e155c2c75 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Cabecera2::class, []); ?>
<?php $component->withName('cabecera2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal039602449bf45efe51ab811d0812b22e155c2c75)): ?>
<?php $component = $__componentOriginal039602449bf45efe51ab811d0812b22e155c2c75; ?>
<?php unset($__componentOriginal039602449bf45efe51ab811d0812b22e155c2c75); ?>
<?php endif; ?>
<body>
  <section class="section1-detrasde" id="seccion__inicio">
    <div class="section1-detrasde__textos">
       <h1 class="section1-detrasde__textos__text1">DETRÁS DE</h1>
       <h2 class="section1-detrasde__textos__text2">Coorsa</h2>
    </div>
 </section>

 <section class="section2-detrasde">
   <div class="section2-detrasde__text1">
     <h2 class="">MÁS QUE UNA EMPRESA</h2>
     <h2 class="">SOMOS UNA FAMILIA</h2>
   </div>
 </section>

<section class="section3-detrasde">
<div class="swiper-container section3-detrasde__slider">
       <div class="swiper-wrapper">
         <!-- Slides -->
         <div class="swiper-slide">
           <div class="picture">
             <p class="imglist">
                <a href="assets/img/JPG/Detras de 35� opacidad (1).jpg" data-fancybox="cumpleaños" data-caption="This image has a caption 1">
                  <img src="assets/img/JPG/Detras de 35� opacidad (1).jpg" />
                </a>
   
                <a href="assets/img/JPG/detras/cumple/1.jpg" data-fancybox="cumpleaños">
                   <img src="assets/img/JPG/detras/cumple/1.jpg" />
                </a>
   
                <a href="assets/img/JPG/detras/cumple/2.jpg" data-fancybox="cumpleaños" >
                   <img src="assets/img/JPG/detras/cumple/2.jpg" />
                </a>
   
                <a href="assets/img/JPG/detras/cumple/3.jpg" data-fancybox="cumpleaños" >
                  <img src="assets/img/JPG/detras/cumple/3.jpg" />
                </a>
             </p>
           </div>
         </div>
         <div class="swiper-slide">
           <div class="picture">
           <p class="imglist">
                <a href="assets/img/JPG/Detras de 35� opacidad (2).jpg" data-fancybox="añonuevo">
                  <img src="assets/img/JPG/Detras de 35� opacidad (2).jpg" />
                </a>
   
                <a href="assets/img/JPG/detras/anio_nuevo/1.JPG" data-fancybox="añonuevo">
                   <img src="assets/img/JPG/detras/anio_nuevo/1.JPG" />
                </a>
   
                <a href="assets/img/JPG/detras/anio_nuevo/2.JPG" data-fancybox="añonuevo" >
                   <img src="assets/img/JPG/detras/anio_nuevo/2.JPG" />
                </a>
   
                <a href="assets/img/JPG/detras/anio_nuevo/3.JPG" data-fancybox="añonuevo" >
                  <img src="assets/img/JPG/detras/anio_nuevo/3.JPG" />
                </a>

                <a href="assets/img/JPG/detras/anio_nuevo/4.JPG" data-fancybox="añonuevo" >
                  <img src="assets/img/JPG/detras/anio_nuevo/4.JPG" />
                </a>

                <a href="assets/img/JPG/detras/anio_nuevo/5.JPG" data-fancybox="añonuevo" >
                  <img src="assets/img/JPG/detras/anio_nuevo/5.JPG" />
                </a>

                <a href="assets/img/JPG/detras/anio_nuevo/6.JPG" data-fancybox="añonuevo" >
                  <img src="assets/img/JPG/detras/anio_nuevo/6.JPG" />
                </a>
             </p>
           </div>
         </div>
         <div class="swiper-slide">
           <div class="picture">
             <p class="imglist">
                <a href="assets/img/JPG/Detras de 35� opacidad (3).jpg" data-fancybox="asociacion">
                  <img src="assets/img/JPG/Detras de 35� opacidad (3).jpg" alt="">
                </a>
   
                <a href="assets/img/JPG/detras/asociacion/1.JPG" data-fancybox="asociacion">
                   <img src="assets/img/JPG/detras/asociacion/1.JPG" />
                </a>
   
                <a href="assets/img/JPG/detras/asociacion/2.JPG" data-fancybox="asociacion" >
                   <img src="assets/img/JPG/detras/asociacion/2.JPG" />
                </a>
   
                <a href="assets/img/JPG/detras/asociacion/3.JPG" data-fancybox="asociacion" >
                  <img src="assets/img/JPG/detras/asociacion/3.JPG" />
                </a>
                
                <a href="assets/img/JPG/detras/asociacion/4.JPG" data-fancybox="asociacion" >
                  <img src="assets/img/JPG/detras/asociacion/4.JPG" />
                </a>

                <a href="assets/img/JPG/detras/asociacion/5.JPG" data-fancybox="asociacion" >
                  <img src="assets/img/JPG/detras/asociacion/5.JPG" />
                </a>

                <a href="assets/img/JPG/detras/asociacion/6.JPG" data-fancybox="asociacion" >
                  <img src="assets/img/JPG/detras/asociacion/6.JPG" />
                </a>
             </p>
           </div>
         </div>

         
</section>

<section class="section4-detrasde">
   <h4 class="section4-detrasde__text">
       En COORSA nos interesa que cada uno de nuestros integrantes se desarrolle
       de manera profesional y personal.
   </h4>
</section>
  
<?php if (isset($component)) { $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Footer::class, []); ?>
<?php $component->withName('footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?> <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf)): ?>
<?php $component = $__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf; ?>
<?php unset($__componentOriginal88b1957f21f7f49b400717e8d0a27189798132bf); ?>
<?php endif; ?>
  </body>
  <?php /**PATH C:\laragon\www\SitioWeb\resources\views/detras_de.blade.php ENDPATH**/ ?>